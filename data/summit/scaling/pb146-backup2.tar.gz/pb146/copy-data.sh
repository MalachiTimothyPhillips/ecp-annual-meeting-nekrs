#!/bin/bash
baseDir=/gpfs/alpine/scratch/malachi/csc262/siam-pp-22/pb146/runs

# setup dir
for preconditioner in "asm" "ras" "cheby-asm" "cheby-ras" "semfem" "cheby-jac"; do
  for nnodes in 1 2 4 8 16; do
    for precision in "fp64" "fp32" "fp16"; do
      cd $precision
      mkdir $preconditioner-$nnodes
      cd ../
    done
  done
done

for preconditioner in "asm" "ras" "cheby-asm" "cheby-ras" "semfem" "cheby-jac"; do
  for nnodes in 1 2 4 8 16; do
    cp $baseDir/$preconditioner-fp16-$nnodes/nekRS_* fp16/$preconditioner-$nnodes/
    cp $baseDir/$preconditioner-fp32-$nnodes/nekRS_* fp32/$preconditioner-$nnodes/
    cp $baseDir/$preconditioner-fp64-$nnodes/nekRS_* fp64/$preconditioner-$nnodes/
  done
done

